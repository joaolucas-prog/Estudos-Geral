package org.hibernate.validator.referenceguide.chapter11.cdi.methodvalidation;

public class Car {
}
